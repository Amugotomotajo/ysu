import { JSX } from 'react/jsx-runtime';
import { useEffect, useState } from 'react';
import axios from 'axios'
import { Button, Card, List } from 'antd';
import { useNavigate } from 'react-router-dom';

export const MenuListPage =  ():JSX.Element => {
    const navigate = useNavigate();

    const Mainpage = () => {
        navigate("/");
        };  

    const [menu, setMenu] = useState([]);


    
    useEffect(() => {
        // fetch(url, options) : Http 요청 함수
        axios.get("/menu").then((res) => {
          setMenu(res.data)
        console.log(res)
        })
    },[])
  
  return (
    <body>
    <div className="App">
      <Card>메뉴<Button type="primary" onClick={Mainpage}>home</Button></Card>
        <List>
          <td>메뉴</td>
          {menu.map(menu => (
            <List.Item key={menu['menu_id']}>
              <List.Item>{menu['menu_id']}</List.Item>
              <List.Item>{menu['menu_name']}</List.Item>
              <List.Item>({menu['menu_corner']})</List.Item>
              <List.Item>({menu['menu_price']})</List.Item>
              <List.Item>({menu['menu_pack']})</List.Item>
              <List.Item>({menu['menu_image']})</List.Item>
              <List.Item>({menu['menu_sales']})</List.Item>
              <List.Item>({menu['menu_regist']})</List.Item>
            </List.Item>
          ))}
        </List>
    </div>
    </body>
  );
}

 